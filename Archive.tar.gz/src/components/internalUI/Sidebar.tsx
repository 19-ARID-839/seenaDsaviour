// components/Sidebar.tsx
import {
  LayoutDashboard,
  BookOpen,
  GraduationCap,
  Users,
  Brain,
  Menu,
} from "lucide-react";
import { useState } from "react";
import clsx from "clsx";

const menuItems = [
  { title: "Dashboard", icon: LayoutDashboard },
  { title: "Courses", icon: BookOpen },
  { title: "Students", icon: GraduationCap },
  { title: "Community", icon: Users },
  { title: "AI Tutor", icon: Brain },
];

export default function Sidebar() {
  const [isOpen, setIsOpen] = useState(true);

  return (
    <div className="flex">
      <div
        className={clsx(
          "h-screen bg-[#0D0F1A] text-white transition-all duration-300 shadow-xl",
          isOpen ? "w-56" : "w-20"
        )}
      >
        {/* Toggle Button */}
        <div className="flex items-center justify-between px-4 py-4">
          <span className={clsx("text-xl font-bold", !isOpen && "hidden")}>
            EduAI
          </span>
          <Menu
            onClick={() => setIsOpen(!isOpen)}
            className="cursor-pointer text-gray-400 hover:text-white"
          />
        </div>

        {/* Menu Items */}
        <nav className="mt-4 space-y-2">
          {menuItems.map(({ title, icon: Icon }) => (
            <div
              key={title}
              className="group flex items-center gap-4 px-4 py-3 cursor-pointer hover:bg-[#1A1D2E] transition-colors"
            >
              <Icon className="w-6 h-6 text-gray-300 group-hover:text-white" />
              {isOpen && <span className="text-sm">{title}</span>}
              {!isOpen && (
                <span className="sr-only group-hover:not-sr-only absolute left-20 bg-black text-white px-2 py-1 text-xs rounded shadow-lg">
                  {title}
                </span>
              )}
            </div>
          ))}
        </nav>
      </div>

      {/* Content Placeholder
      <div className="flex-1 p-8 bg-[#f3f4f6] min-h-screen">
        <h1 className="text-2xl font-semibold">Main Content Area</h1>
      </div> */}
    </div>
  );
}
